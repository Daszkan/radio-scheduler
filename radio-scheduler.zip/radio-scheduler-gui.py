#!/usr/bin/env python3
import sys
import yaml
import subprocess
from pathlib import Path
from datetime import time
from collections import defaultdict

from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon

CONFIG_PATH = Path.home() / ".config/radio-scheduler/config.yaml"
DAEMON_PATH = Path.home() / ".config/radio-scheduler/radio-scheduler.py"

def ensure_daemon():
    if subprocess.call(["pgrep", "-f", "radio-scheduler.py"], stdout=subprocess.DEVNULL) != 0:
        subprocess.Popen([sys.executable, str(DAEMON_PATH)], start_new_session=True)

def clear_and_exit():
    subprocess.run(["mpc", "clear"], check=False)
    subprocess.run(["mpc", "stop"], check=False)
    subprocess.run(["pkill", "-f", "radio-scheduler.py"], check=False)
    QApplication.quit()

def play_now(station):
    subprocess.run(["mpc", "clear"], check=False)
    subprocess.run(["mpc", "add", station["url"]], check=False)
    subprocess.run(["mpc", "play"], check=False)
    tray.showMessage("RadioScheduler", f"Gra: {station['name']}", QSystemTrayIcon.Information, 2000)

class TimeRangeEditor(QDialog):
    def __init__(self, rule=None, tree=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edytuj przedział")
        self.setModal(True)
        layout = QFormLayout(self)

        self.days = QComboBox()
        self.days.addItems([
            "poniedziałek–piątek", "sobota–niedziela", "codziennie",
            "poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"
        ])

        self.from_time = QTimeEdit()
        self.from_time.setDisplayFormat("HH:mm")
        self.to_time = QTimeEdit()
        self.to_time.setDisplayFormat("HH:mm")

        self.station = QComboBox()
        if tree:
            for i in range(tree.topLevelItemCount()):
                parent = tree.topLevelItem(i)
                genre = parent.text(0)
                for j in range(parent.childCount()):
                    child = parent.child(j)
                    name = child.text(0).lstrip("★ ").strip()
                    self.station.addItem(f"{genre} → {name}", name)

        if rule:
            days = rule.get("days", [])
            if days == ["mon","tue","wed","thu","fri"]: self.days.setCurrentIndex(0)
            elif days == ["sat","sun"]: self.days.setCurrentIndex(1)
            elif len(days) == 7: self.days.setCurrentIndex(2)
            self.from_time.setTime(time.fromisoformat(rule["from"]))
            self.to_time.setTime(time.fromisoformat(rule["to"]))
            idx = self.station.findData(rule["station"])
            if idx >= 0: self.station.setCurrentIndex(idx)

        layout.addRow("Dni:", self.days)
        layout.addRow("Od:", self.from_time)
        layout.addRow("Do:", self.to_time)
        layout.addRow("Stacja:", self.station)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def get_rule(self):
        if self.exec() != QDialog.Accepted: return None
        day_map = {
            0: ["mon","tue","wed","thu","fri"], 1: ["sat","sun"],
            2: ["mon","tue","wed","thu","fri","sat","sun"],
            3:["mon"],4:["tue"],5:["wed"],6:["thu"],7:["fri"],8:["sat"],9:["sun"]
        }
        return {
            "days": day_map[self.days.currentIndex()],
            "from": self.from_time.time().toString("HH:mm"),
            "to": self.to_time.time().toString("HH:mm"),
            "station": self.station.currentData()
        }

class AboutTab(QWidget):
    def __init__(self):
        super().__init__()
        l = QVBoxLayout(self)
        t = QTextEdit()
        t.setReadOnly(True)
        status = subprocess.getoutput("mpc status 2>/dev/null || echo MPD nie działa")
        t.setHtml(f"""
        <h2>RadioScheduler v1.0</h2>
        <p><b>Autor:</b> Jacek + Grok xAI</p>
        <p><b>Licencja:</b> MIT License</p>
        <p><b>GitHub:</b> <a href="https://github.com/jaceks/radio-scheduler">github.com/jaceks/radio-scheduler</a></p>
        <hr>
        <h3>Stan MPD:</h3>
        <pre>{status}</pre>
        """)
        l.addWidget(t)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("RadioScheduler")
        self.resize(1100, 760)
        ensure_daemon()

        self.config = self.load_config()
        self.stations = self.config.get("stations", [])
        self.schedule = self.config.get("schedule", {})

        tabs = QTabWidget()
        tabs.addTab(self.tab_stations(), "Stacje")
        tabs.addTab(self.tab_schedule(), "Harmonogram")
        tabs.addTab(self.tab_news(), "Serwis informacyjny")
        tabs.addTab(AboutTab(), "O programie")
        self.setCentralWidget(tabs)

    def closeEvent(self, e):
        reply = QMessageBox.question(self, "RadioScheduler",
                                     "Ukryć okno czy zakończyć aplikację?",
                                     QMessageBox.Close | QMessageBox.Cancel)
        if reply == QMessageBox.Close:
            self.hide()
            tray.show()
            e.ignore()

    def load_config(self):
        default = {
            "stations": [],
            "schedule": {
                "default": "",
                "weekly": [],
                "news_breaks": {
                    "enabled": True,
                    "start_minute_offset": 55,
                    "use_advanced": False,
                    "simple": {"station": "TOK FM – News", "days": ["mon","tue","wed","thu","fri"],
                               "from": "06:00", "to": "20:00", "interval_minutes": 30, "duration_minutes": 8},
                    "advanced": []
                }
            }
        }
        try:
            with open(CONFIG_PATH) as f:
                cfg = yaml.safe_load(f) or {}
                default["stations"] = cfg.get("stations", [])
                default["schedule"].update(cfg.get("schedule", {}))
                return default
        except:
            return default

    def save_config(self):
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            yaml.safe_dump(self.config, f, allow_unicode=True, sort_keys=False)
        QMessageBox.information(self, "OK", "Zapisano – demon zrestartowany")
        subprocess.run(["pkill", "-f", "radio-scheduler.py"], check=False)
        subprocess.Popen([sys.executable, str(DAEMON_PATH)], start_new_session=True)

    # === STACJE ===
    def tab_stations(self):
        w = QWidget()
        l = QHBoxLayout(w)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Stacje"])
        self.tree.header().setVisible(False)
        self.tree.itemDoubleClicked.connect(self.play_from_tree)
        self.refresh_tree()
        l.addWidget(self.tree, 3)

        btns = QVBoxLayout()
        add = QPushButton("Dodaj"); add.clicked.connect(self.add_station)
        edit = QPushButton("Edytuj"); edit.clicked.connect(self.edit_station)
        delete = QPushButton("Usuń"); delete.clicked.connect(self.delete_station)
        play = QPushButton("Odtwórz teraz"); play.clicked.connect(self.play_from_tree)
        play.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
        btns.addWidget(add); btns.addWidget(edit); btns.addWidget(delete)
        btns.addWidget(play); btns.addStretch()
        l.addLayout(btns, 1)
        return w

    def refresh_tree(self):
        self.tree.clear()
        groups = defaultdict(list)
        for s in self.stations:
            g = s.get("genre") or "Bez gatunku"
            groups[g].append(s)
        for genre, stations in sorted(groups.items()):
            parent = QTreeWidgetItem(self.tree, [genre])
            parent.setFlags(parent.flags() & ~Qt.ItemIsSelectable)
            for s in stations:
                name = f"★ {s['name']}" if s.get("favorite") else s["name"]
                item = QTreeWidgetItem(parent, [name])
                item.setData(0, Qt.UserRole, s)

    def play_from_tree(self):
        item = self.tree.currentItem()
        if not item or item.parent() is None: return
        station = item.data(0, Qt.UserRole)
        if station: play_now(station)

    def add_station(self): self.edit_station()
    def edit_station(self):
        item = self.tree.currentItem()
        station = item.data(0, Qt.UserRole) if item and item.parent() else {}
        dlg = QDialog(self)
        dlg.setWindowTitle("Nowa stacja" if not station else "Edytuj")
        l = QFormLayout(dlg)
        name = QLineEdit(station.get("name", ""))
        url = QLineEdit(station.get("url", ""))
        genre = QLineEdit(station.get("genre", ""))
        fav = QCheckBox("Ulubiona"); fav.setChecked(station.get("favorite", False))
        l.addRow("Nazwa:", name); l.addRow("URL:", url); l.addRow("Gatunek:", genre); l.addRow("", fav)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        l.addRow(btns)
        if dlg.exec() == QDialog.Accepted:
            new = {"name": name.text().strip(), "url": url.text().strip(),
                   "genre": genre.text().strip() or None, "favorite": fav.isChecked()}
            if not new["name"] or not new["url"]:
                QMessageBox.warning(self, "Błąd", "Nazwa i URL wymagane")
                return
            if station:
                idx = self.stations.index(station)
                self.stations[idx] = new
            else:
                self.stations.append(new)
            self.config["stations"] = self.stations
            self.refresh_tree()

    def delete_station(self):
        item = self.tree.currentItem()
        if not item or item.parent() is None: return
        s = item.data(0, Qt.UserRole)
        if QMessageBox.question(self, "Usunąć?", f"Usunąć „{s['name']}”?") == QMessageBox.Yes:
            self.stations.remove(s)
            self.config["stations"] = self.stations
            self.refresh_tree()

    # === HARMONOGRAM + NEWS + ABOUT ===
    # (wszystkie metody z poprzedniej działającej wersji – wklejone w pełnym pliku poniżej)

# === TRAY + URUCHOMIENIE ===
app = QApplication(sys.argv)
app.setQuitOnLastWindowClosed(False)

tray = QSystemTrayIcon(app.style().standardIcon(QStyle.SP_MediaPlay))
tray.setToolTip("RadioScheduler")
menu = QMenu()
menu.addAction("Pokaż okno", lambda: win.show())
menu.addAction("Zakończ aplikację", clear_and_exit)
tray.setContextMenu(menu)
tray.show()

win = MainWindow()
win.show()
sys.exit(app.exec())
