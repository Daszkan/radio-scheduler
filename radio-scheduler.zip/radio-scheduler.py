#!/usr/bin/env python3
import time
import yaml
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

CONFIG_PATH = Path.home() / ".config/radio-scheduler/config.yaml"

def load_config():
    if not CONFIG_PATH.exists():
        return {"stations": [], "schedule": {"default": "", "weekly": [], "news_breaks": {"enabled": True}}}
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def find_station(name, stations):
    for s in stations:
        if s["name"] == name:
            return s["url"]
    return None

def play(url):
    subprocess.run(["mpc", "clear"], check=False)
    subprocess.run(["mpc", "add", url], check=False)
    subprocess.run(["mpc", "play"], check=False)

def main():
    while True:
        config = load_config()
        stations = config.get("stations", [])
        sched = config.get("schedule", {})
        now = datetime.now()
        weekday = now.strftime("%a").lower()[:3]
        current_time = now.strftime("%H:%M")

        # News breaks (advanced first)
        news_cfg = sched.get("news_breaks", {})
        if news_cfg.get("enabled", True):
            offset = news_cfg.get("start_minute_offset", 0)
            if news_cfg.get("use_advanced", False):
                for rule in news_cfg.get("advanced", []):
                    if weekday in rule["days"]:
                        start = datetime.strptime(rule["from"], "%H:%M").time()
                        end = datetime.strptime(rule["to"], "%H:%M").time()
                        if start <= now.time() <= end:
                            # Calculate next news time with offset
                            base = datetime.combine(now.date(), start)
                            minutes_since_start = (now - base).total_seconds() // 60
                            next_news = base + timedelta(minutes=((minutes_since_start // rule["interval_minutes"] + 1) * rule["interval_minutes"]))
                            next_news = next_news.replace(minute=offset if offset else next_news.minute)
                            if now >= next_news and now < next_news + timedelta(minutes=rule.get("duration_minutes", 8)):
                                url = find_station(rule["station"], stations)
                                if url:
                                    play(url)
                                    time.sleep(60)
                                    continue
            else:
                simple = news_cfg.get("simple", {})
                if weekday in simple.get("days", []):
                    start = datetime.strptime(simple["from"], "%H:%M").time()
                    end = datetime.strptime(simple["to"], "%H:%M").time()
                    if start <= now.time() <= end:
                        interval = simple.get("interval_minutes", 30)
                        duration = simple.get("duration_minutes", 8)
                        base = datetime.combine(now.date(), start)
                        minutes_since_start = (now - base).total_seconds() // 60
                        next_news = base + timedelta(minutes=((minutes_since_start // interval + 1) * interval))
                        next_news = next_news.replace(minute=offset if offset else next_news.minute)
                        if now >= next_news and now < next_news + timedelta(minutes=duration):
                            url = find_station(simple["station"], stations)
                            if url:
                                play(url)
                                time.sleep(60)
                                continue

        # Weekly schedule
        played = False
        for rule in sched.get("weekly", []):
            if weekday in rule["days"]:
                if rule["from"] <= current_time < rule["to"]:
                    url = find_station(rule["station"], stations)
                    if url:
                        play(url)
                        played = True
                        break
        if not played:
            default = sched.get("default", "")
            if default:
                url = find_station(default, stations)
                if url:
                    play(url)

        time.sleep(10)

if __name__ == "__main__":
    main()
